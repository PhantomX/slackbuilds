#!/bin/sh
/usr/bin/spamassassin -e
