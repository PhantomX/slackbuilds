#!/bin/sh

PSXDIR=GAMES_PREFIX_OPT/pSX

# execute program (with args)
export LD_PRELOAD="/usr/lib/libGL.so:${LD_PRELOAD}"
exec ${PSXDIR}/pSX "$@"
