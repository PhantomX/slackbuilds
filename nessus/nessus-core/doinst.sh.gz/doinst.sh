#!/bin/sh

##Make it so config files are not overwritten
config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

## List of conf files to check.  The conf files in your package should end in .new
config etc/nessus/nessusd.conf.new
config etc/nessus/nessusd.rules.new
config etc/nessus/nessusd.users.new
config etc/pki/nessus/private/CA/cakey.pem.new
config etc/pki/nessus/private/CA/serverkey.pem.new
config etc/pki/nessus/private/CA/cacert.pem.new
config etc/pki/nessus/private/CA/servercert.pem.new

# Fix permissions
chmod 750 /etc/rc.d/rc.nessusd
chmod 700 /etc/pki/nessus/private/CA
chmod 600 /etc/pki/nessus/private/CA/{cakey,serverkey}.pem*
chmod 644 /etc/pki/nessus/private/CA/{cacert,servercert}.pem*
chmod 600 etc/nessus/nessusd.conf* etc/nessus/nessusd.rules* etc/nessus/nessusd.users*
chmod 750 /var/lib/nessus
