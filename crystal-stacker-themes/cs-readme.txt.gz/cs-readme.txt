Crystal Stacker (c) 2006 NewCreature Design
-------------------------------------------

Crystal Stacker is freeware. This means you can pass copies around freely
provided you include this document in it's original form in your distribution.
Please see the "Contacting Us" section of this document if you need to contact
us for any reason.


Disclaimer
----------

NewCreature Design makes no guarantees regarding the Crystal Stacker software.
We are not responsible for damages caused by it, though the software is not
known to cause any problems. If you have trouble with the software, see the
"Contacting Us" section of this document.


Description
-----------

If you've played Columns then you know what Crystal Stacker is all about. Match
3 or more of the same color crystals either horizontally, vertically, or dia-
gonally to destroy them. For every 45 crystals you destroy, the level increases
and the crystals fall faster. The higher the level, the more points you are
awarded for destroying crystals.


System Requirements
-------------------

A 486 or higher PC.
VGA or better graphics card.


===============================================================================


How To Play
-----------

When the game starts, you have an empty board and a stack of crytals falling
from the top. Your job is to keep the board as empty as possible by creating
runs. A run is where the board contains 3 or more of the same color crystal
connected either horizontally, vertically, or diagonally. When you create runs
those crystals are destroyed and you play on. Once you run out of room for the
falling stack of crystals you top out and the game ends.


Combos
------

A combo occurs when crystals are destroyed and more runs are created as a
result. When a combo occurs a message will scroll in the message bar indicating
the size of the combo. The larger the combo, the more points you are awarded.


Wild Cards
----------

A wild card is a crystal that will match any color. In tight situations where
you don't have time to think, these can be very valuable.

You can distinguish a wild card from the other crystals because its color
changes continually.


Bombs
-----

A bomb is a special stack of crystals that specializes in removing a certain
color from the board. All crystals the same color as the crystal the bomb lands
on will be removed from the board. Landing on a wild card will cause all
crystals to be removed. If the bomb doesn't land on a crystal, it will become
randomly colored crystals.

Bombs have the appearance of a bright flashing stack of crystals.


===============================================================================


Game Modes
----------

Crystal Stacker offers a number of game modes for 1 or 2 players, each with a
different objective. 1 Player mode scores are stored in a table which can be
viewed from the main menu.

2 player modes can either be played in normal or battle mode. These modes are
essentially the same, but battle mode allows attacks, which add indestructible
blocks to the opposing players board. In order to attack the other player you
have to destroy at least 7 crystals at once. An attack can add up to 3 rows of
solid blocks at a time.


1 Player - Classic
------------------

This mode plays like classic Columns. Just try to get the high score.


1 Player - Destroyer
--------------------

You must destroy a set number of crystals to try to beat the best time.


1 Player - Frenzy
-----------------

This mode is like classic mode, except you have a time limit.


2 Player - Top Score
--------------------

Play until both players top out. The player with the highest score at the end
wins.


2 Player - Last Out
-------------------

The last surviving player wins.


2 Player - Destroyer
--------------------

The first player to destroy the specified number of crystals wins.


===============================================================================


Themes
------

Themes are used to give a new look to the game. They can be loaded from the
options menu. New themes can be downloaded from our web site or you can create
new themes with the editor.


Command Line Arguments
----------------------

-v             Display the current version number

-nosound       Disable sound support


Contacting Us
-------------

If you have general questions about our programs or anything else you can
contact us via e-mail. Please report any bugs you find in our software as well.
Visit our web sites for the latest updates and releases.


E-mail Address
--------------

todd@t3-i.com


Web Address
-----------

http://www.t3-i.com