#!/bin/sh

# start functions
usage() {
	echo "Usage:"
	echo "- As root, to set the default backend, system-wide:"
	echo "       $0 -b <backend name>"
	echo
	echo "- As a normal user, to run a program with a specific backend:"
	echo "       $0 -b <backend name> <program name> [program options...]"
	echo
	echo "- \"backend name\" is one of gstreamer or xine"
	echo "- \"program name\" is one of totem, totem-audio-preview,"
	echo "  totem-video-indexer or totem-video-thumbnailer"
	echo
	exit 1
}

set_backend() {
	TOTEM_BACKEND=$1
	# Default to GStreamer if there's no config
	if [ -z $TOTEM_BACKEND ] ; then
		echo "*** No backend name passed ***"
		usage
	fi
	# Default to GStreamer if the backend is invalid
	if [ $TOTEM_BACKEND != "xine" -a $TOTEM_BACKEND != "gstreamer" ] ; then
		echo "*** Invalid backend name ***"
		usage
	fi

	# FIXME if someone can explain update-alternatives to me

	exit 0
}
# end functions

# If root, just try to set the default backend
if [ "$UID" -eq "0" ] ; then
	if [ "$1" != "-b" -o -z "$2" ] ; then
		usage;
	fi
	set_backend $2
else
	if [ "$1" != "-b" -o -z "$2" ] ; then
		usage;
	fi
	TOTEM_BACKEND=$2

	if [ $TOTEM_BACKEND != "xine" -a $TOTEM_BACKEND != "gstreamer" ] ; then
		echo "*** Invalid backend name passed ***"
		usage
	fi

	BIN=$3
	if [ -z "$BIN" ] ; then
		echo "*** No program name passed ***"
		usage
	fi
	if [ $BIN != "totem" -a $BIN != "totem-audio-preview" -a $BIN != "totem-video-indexer" -a $BIN != "totem-video-thumbnailer" ] ; then
		echo "*** Wrong program name ***"
		usage
	fi
	shift 3
	LD_PRELOAD=libgdk-x11-2.0.so.0:libbaconvideowidget-$TOTEM_BACKEND.so.0.0.0 exec $BIN "$@"
fi

