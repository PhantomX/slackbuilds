#!/bin/sh
#
# Google Earth startup script
# Modified for Slackware by Ken Zalewski
#

GOOGLEEARTH_DATA_PATH=/usr/lib/googleearth

LD_LIBRARY_PATH=.:${GOOGLEEARTH_DATA_PATH}:${LD_LIBRARY_PATH}
export LD_LIBRARY_PATH

# Let's boogie!
if [ -x "${GOOGLEEARTH_DATA_PATH}/googleearth-bin" ]
then
	cd "${GOOGLEEARTH_DATA_PATH}/"
	exec "./googleearth-bin" $*
fi
echo "Couldn't run Google Earth (googleearth-bin). Is GOOGLEEARTH_DATA_PATH set?"
exit 1

# end of googleearth ...

