/* This file is here to prevent a file conflict on multiarch systems. A
 * conflict will occur because config.h has arch-specific definitions.
 *
 * DO NOT INCLUDE THE NEW FILE DIRECTLY -- ALWAYS INCLUDE THIS ONE INSTEAD. */

#if defined(__i386__)
#include "config-i386.h"
#elif defined(__ia64__)
#include "config-ia64.h"
#elif defined(__powerpc64__)
#include "config-ppc64.h"
#elif defined(__powerpc__)
#include "config-ppc.h"
#elif defined(__s390x__)
#include "config-s390x.h"
#elif defined(__s390__)
#include "config-s390.h"
#elif defined(__x86_64__)
#include "config-x86_64.h"
#elif defined(__alpha__)
#include "config-alpha.h"
#elif defined(__arm__)
#include "config-arm.h"
#elif defined(__sparc__) && defined(__arch64__)
#include "config-sparc64.h"
#elif defined(__sparc__)
#include "config-sparc.h"
#elif defined(__hppa__) && defined(__LP64__)
#include "config-parisc64.h"
#elif defined(__hppa__)
#include "config-parisc.h"
#elif defined(__mips__)
#include "config-mips.h"
#elif defined(__mipsel__)
#include "config-mipsel.h"
#elif defined(__mips64__)
#include "config-mipsx.h"
#elif defined(__sh64__)
#include "config-sh64.h"
#elif defined(__sh__)
#include "config-sh.h"
#else
#error "This bitlbee-devel package does not work your architecture?"
#endif
