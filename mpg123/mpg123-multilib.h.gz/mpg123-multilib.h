/* qconfig.h */
/* This file is here to prevent a file conflict on multiarch systems.  A
 * conflict will occur because qconfig.h has arch-specific definitions.
 *
 * DO NOT INCLUDE THE NEW FILE DIRECTLY -- ALWAYS INCLUDE THIS ONE INSTEAD. */

#if defined(__x86_64__)
# include "mpg123-x86_64.h"
#elif defined(__i386__)
# include "mpg123-i386.h"
#elif defined(__powerpc64__)
# include "mpg123-ppc64.h"
#elif defined(__powerpc__)
# include "mpg123-ppc.h"
#elif defined(__s390x__)
# include "mpg123-s390x.h"
#elif defined(__s390__)
# include "mpg123-s390.h"
#elif defined(__sparc__) && defined (__arch64__)
# include "mpg123-sparc64.h"
#elif defined(__sparc__)
# include "mpg123-sparc.h"
#else
/* Should never reach this point */
#error "This mpg123 package does not work your architecture?"
#endif

