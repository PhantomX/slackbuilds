#!/bin/sh
# Code based on startfluxbox from fluxbox package.

command="`basename \"$0\"`"
serverconf="$HOME/.Xmetisse"
startup="$HOME/.fvwm-metisse/startup"


while [ $# -gt 0 ]; do
    case "$1" in
        -c|--config)
            if [ $# -lt 2 ]; then
                echo "$command:error, missing argument"
                exit 1
            fi
            shift
            startup=$1
        ;;
        -h|--help) cat <<EOF
Usage: $command [-h] [-c startupfile]
EOF
        exit
        ;;
    esac
    shift
done

if [ "$COMPOSITING_SERVER_START" = "yes" -a "$COMPOSITING_SERVER" = "Xmetisse" ]; then
	AT_SPI_DISPLAY=$COMPOSITING_SERVER_DISPLAY
	export AT_SPI_DISPLAY
	XKL_XMODMAP_DISABLE=1
	export XKL_XMODMAP_DISABLE
fi

if [ -r "$serverconf" ]; then
    . "$serverconf"
else
    if [ ! -r "$serverconf" ]; then
        ( cat << 'EOF'
# Xmetisse config:
#
# Lines starting with a '#' are ignored.
METISSE_GEOM=1024x768
export METISSE_GEOM
if [ -z ${DISPLAY} ] ;then
    DISPLAY=:0
fi
METISSE_DISPLAY=:$( expr "$( echo ${DISPLAY} |awk -F'.' '{ print $1 }' | sed -e 's|:|0|g' )" + 1 )
export METISSE_DISPLAY
METISSE_OTHER=
export METISSE_OTHER
EOF
    ) > "$serverconf"
    fi
    chmod 644 "$serverconf"
    . "$serverconf"
fi

Xmetisse -ac -geometry ${METISSE_GEOM} ${METISSE_DISPLAY} ${METISSE_OTHER} &
sleep 5

if [ -x "$startup" ]; then
    exec "$startup"
elif [ -r "$startup" ]; then
    exec sh "$startup"
else
    if [ ! -d "$HOME/.fvwm-metisse" ]; then
        mkdir -p "$HOME/.fvwm-metisse"
    fi
    if [ ! -r "$startup" ]; then
        ( cat << EOF
# .fvwm-metisse startup-script:
#
# Lines starting with a '#' are ignored.

# You can set your favourite wallpaper here if you don't want
# to do it from your style.
#
# fbsetbg -f $HOME/pictures/wallpaper.png
#
# This sets a black background

# /usr/bin/fbsetroot -solid black

# This shows the fluxbox-splash-screen
# fbsetbg -C /usr/share/fluxbox/splash.jpg

# Other examples. Check man xset for details.
#
# Turn off beeps:
# xset -b
#
# Increase the keyboard repeat-rate:
# xset r rate 195 35
#
# Your own fonts-dir:
# xset +fp "$HOME/.fonts"
#
# Your favourite mouse cursor:
# xsetroot -cursor_name right_ptr
#
# Change your keymap:
# xmodmap "$HOME/.Xmodmap"

# Applications you want to run with metisse
# MAKE SURE THAT APPS THAT KEEP RUNNING HAVE AN ''&'' AT THE END.
#
# unclutter -idle 2 &
# wmnd &
# wmsmixer -w &
# idesk &

# And last but not least we start metisse.
# Because it is the last app you have to run it with ''exec'' before it.

exec /usr/bin/metisse-start-fvwm -wd \${METISSE_DISPLAY}

EOF
    ) > "$startup"
    fi
    chmod 644 "$startup"
    exec sh "$startup"
fi
