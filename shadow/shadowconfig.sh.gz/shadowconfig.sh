#!/bin/sh
# turn shadow passwords on or off on a Debian system
#
#       'shadowconfig on' will turn shadow passwords on;
#       'shadowconfig off' will turn shadow passwords off.
#
#       shadowconfig will print an error message and exit with
#       a nonzero code if it finds anything awry.  If that happens,
#       you should correct the error and run it again.
#
#       Turning shadow passwords on when they are already on, or
#       off when they are already off, is harmless.
#
#       Be aware that account expiration dates are only supported
#       by shadow passwords -- these dates will be lost when converting
#       from shadow to non-shadow passwords.  If you need to save this
#       information, back up your /etc/shadow before turning off
#       shadow passwords.
#

set -e

shadowon () {
bash<<- EOF
    set -e
    pwck -q
    grpck -p
    pwconv
    grpconv
    cd /etc
    chown root:root passwd group
    chmod 644 passwd group
    chown root:shadow shadow gshadow
    chmod 640 shadow gshadow
EOF
}

shadowoff () {
bash<<- EOF
    set -e
    pwck -q
    grpck -p
    pwunconv
    grpunconv
    cd /etc
    # sometimes the passwd perms get munged
    chown root:root passwd group
    chmod 644 passwd group
EOF
}

case "$1" in
    "on")
	if shadowon ; then
	    echo Shadow passwords are now on.
	else
	    echo Please correct the error and rerun \`$0 on\'
	    exit 1
	fi
	;;
    "off")
	if shadowoff ; then
	    echo Shadow passwords are now off.
	else
	    echo Please correct the error and rerun \`$0 off\'
	    exit 1
	fi
	;;
     *)
	echo Usage: $0 on \| off
	;;
esac
