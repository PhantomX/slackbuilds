cat >>po/bg.po <<EOF

msgid "Suspend"
msgstr "Приспиване"
EOF
cat >>po/bn_IN.po <<EOF

msgid "Suspend"
msgstr "স্থগিত"
EOF
cat >>po/bn.po <<EOF

msgid "Suspend"
msgstr "সাসপেন্ড"
EOF
cat >>po/ca.po <<EOF

msgid "Suspend"
msgstr "Atura temporalment"
EOF
cat >>po/cs.po <<EOF

msgid "Suspend"
msgstr "Suspendovat"
EOF
cat >>po/de.po <<EOF

msgid "Suspend"
msgstr "Stromsparmodus"
EOF
cat >>po/dz.po <<EOF

msgid "Suspend"
msgstr "འཕྲལ་བཀག"
EOF
cat >>po/el.po <<EOF

msgid "Suspend"
msgstr "Αναστολή"
EOF
cat >>po/en_CA.po <<EOF

msgid "Suspend"
msgstr "Suspend"
EOF
cat >>po/en_GB.po <<EOF

msgid "Suspend"
msgstr "Suspend"
EOF
cat >>po/es.po <<EOF

msgid "Suspend"
msgstr "Suspender"
EOF
cat >>po/et.po <<EOF

msgid "Suspend"
msgstr ""
EOF
cat >>po/eu.po <<EOF

msgid "Suspend"
msgstr "Eseki"
EOF
cat >>po/fi.po <<EOF

msgid "Suspend"
msgstr "Keskeytystila"
EOF
cat >>po/fr.po <<EOF

msgid "Suspend"
msgstr "Mise en veille prolongée"
EOF
cat >>po/gl.po <<EOF

msgid "Suspend"
msgstr "Suspender"
EOF
cat >>po/gu.po <<EOF

msgid "Suspend"
msgstr "અટકાવો"
EOF
cat >>po/hi.po <<EOF

msgid "Suspend"
msgstr "स्थगित"
EOF
cat >>po/hu.po <<EOF

msgid "Suspend"
msgstr "Felfüggesztés"
EOF
cat >>po/it.po <<EOF

msgid "Suspend"
msgstr "Sospendi"
EOF
cat >>po/ja.po <<EOF

msgid "Suspend"
msgstr "サスペンド"
EOF
cat >>po/ka.po <<EOF

msgid "Suspend"
msgstr "შეჩერება"
EOF
cat >>po/ko.po <<EOF

msgid "Suspend"
msgstr "절전"
EOF
cat >>po/lt.po <<EOF

msgid "Suspend"
msgstr "Užmigdyti"
EOF
cat >>po/lv.po <<EOF

msgid "Suspend"
msgstr "Pārstāt"
EOF
cat >>po/mg.po <<EOF

msgid "Suspend"
msgstr "Ahatoy"
EOF
cat >>po/mk.po <<EOF

msgid "Suspend"
msgstr "Суспендирај"
EOF
cat >>po/ml.po <<EOF

msgid "Suspend"
msgstr "താല്‍ക്കാലികമായി കംപ്യൂട്ടര്‍ നിര്‍ത്തുക"
EOF
cat >>po/nb.po <<EOF

msgid "Suspend"
msgstr "Hvilemodus"
EOF
cat >>po/nl.po <<EOF

msgid "Suspend"
msgstr "Pauzestand"
EOF
cat >>po/or.po <<EOF

msgid "Suspend"
msgstr "ନିଲମ୍ବନ କରନ୍ତୁ"
EOF
cat >>po/pa.po <<EOF

msgid "Suspend"
msgstr "ਮੁਅੱਤਲ"
EOF
cat >>po/pl.po <<EOF

msgid "Suspend"
msgstr "Wstrzymanie"
EOF
cat >>po/pt_BR.po <<EOF

msgid "Suspend"
msgstr "Suspender"
EOF
cat >>po/pt.po <<EOF

msgid "Suspend"
msgstr "Suspender"
EOF
cat >>po/ru.po <<EOF

msgid "Suspend"
msgstr "Ждущий режим"
EOF
cat >>po/sk.po <<EOF

msgid "Suspend"
msgstr ""
EOF
cat >>po/sr@Latn.po <<EOF

msgid "Suspend"
msgstr "Privremeno zaustavi"
EOF
cat >>po/sr.po <<EOF

msgid "Suspend"
msgstr "Привремено заустави"
EOF
cat >>po/sv.po <<EOF

msgid "Suspend"
msgstr "Vänteläge"
EOF
cat >>po/ta.po <<EOF

msgid "Suspend"
msgstr "இடை நீக்கம்"
EOF
cat >>po/th.po <<EOF

msgid "Suspend"
msgstr "พักเครื่อง"
EOF
cat >>po/uk.po <<EOF

msgid "Suspend"
msgstr "Призупиняти"
EOF
cat >>po/vi.po <<EOF

msgid "Suspend"
msgstr "Ngưng"
EOF
cat >>po/zh_CN.po <<EOF

msgid "Suspend"
msgstr "挂起"
EOF
cat >>po/zh_HK.po <<EOF

msgid "Suspend"
msgstr "暫停"
EOF
cat >>po/zh_TW.po <<EOF

msgid "Suspend"
msgstr "暫停"
EOF
