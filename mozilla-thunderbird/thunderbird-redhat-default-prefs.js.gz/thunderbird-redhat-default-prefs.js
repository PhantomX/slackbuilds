pref("app.update.enabled", false);
pref("app.update.autoInstallEnabled", false);
pref("browser.display.use_system_colors",   true);
pref("general.useragent.vendor", "Fedora");
pref("general.useragent.vendorSub", "THUNDERBIRD_RPM_VR");
pref("intl.locale.matchOS", true);

# Make hyperlinks work
pref("network.protocol-handler.app.http", "COMMAND");
pref("network.protocol-handler.app.https", "COMMAND");
pref("network.protocol-handler.app.ftp", "COMMAND");
