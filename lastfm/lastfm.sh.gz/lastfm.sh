#!/bin/sh
RUNDIR=/usr/lib/lastfm

test -d ${HOME}/.lastfm || mkdir ${HOME}/.lastfm
cp -f ${RUNDIR}/last.fm ${HOME}/.lastfm/last.fm
test -d ${HOME}/.lastfm/cache || mkdir -p ${HOME}/.lastfm/cache
test -e ${HOME}/.lastfm/data || ln -sf ${RUNDIR}/data ${HOME}/.lastfm/data
# test -e ${HOME}/.lastfm/extensions || ln -sf ${RUNDIR}/extensions ${HOME}/.lastfm/extensions
# test -e ${HOME}/.lastfm/imageformats || ln -sf ${RUNDIR}/imageformats ${HOME}/.lastfm/imageformats
test -e ${HOME}/.lastfm/services || ln -sf ${RUNDIR}/services ${HOME}/.lastfm/services

export LD_LIBRARY_PATH=${RUNDIR}:${LD_LIBRARY_PATH}
exec $(${HOME}/.lastfm/last.fm "$@" ; sleep 1 ;\
       if ! ps aux | grep "^$USER.*last.fm" | grep Sl >/dev/null 2>&1; then \
       killall -u ${USER} last.fm >/dev/null 2>&1 ; fi ; rm -f ${HOME}/.lastfm/last.fm)

