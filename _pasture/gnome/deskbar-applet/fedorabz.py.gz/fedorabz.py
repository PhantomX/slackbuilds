from gettext import gettext as _

import deskbar.interfaces.Action
import deskbar.interfaces.Match
import deskbar.interfaces.Module
import gnomevfs

HANDLERS = ["FedoraBZModule"]
bzurl="https://bugzilla.redhat.com/bugzilla/show_bug.cgi?id=%s"

class FedoraBZAction(deskbar.interfaces.Action):
  def __init__(self, bugnum):
    deskbar.interfaces.Action.__init__(self, bugnum)
    self._bugnum = bugnum

  def activate(self, text=None):
    gnomevfs.url_show(bzurl % self._bugnum)

  def get_verb(self):
    return _('Open Fedora Bugzilla report <b>#%(name)s</b>')

  def is_valid(self, text=None):
    return self._bugnum.isdigit()

class FedoraBZMatch(deskbar.interfaces.Match):
  def __init__(self, bugnum, **kwargs):
    deskbar.interfaces.Match.__init__(self, bugnum=bugnum, icon="fedorabz.png",
      category="web", **kwargs)
    self.bugnum=bugnum
    self.add_action(FedoraBZAction(bugnum))

  def get_hash(self, text=None):
    return self.bugnum

class FedoraBZModule(deskbar.interfaces.Module):
  INFOS = {
    'icon': deskbar.core.Utils.load_icon('fedorabz.png'),
    'name': 'Fedora Bugzilla Module',
    'description': 'Open a specific bug number in Fedora\'s Bugzilla',
    'version': '1.0.0.0',
  }

  def __init__(self):
    deskbar.interfaces.Module.__init__(self)

  def query(self, text):
    self._emit_query_ready(text, [FedoraBZMatch(text)])
