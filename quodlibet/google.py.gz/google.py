# Copyright 2006 Jeffrey C. Ollie <jeff@ocjtech.us>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation

GOOGLE_MUSICSEARCH_URL = "http://www.google.com/musicsearch?q=%s&res=%s"

from util import website
from urllib import quote
import gtk

from plugins.songsmenu import SongsMenuPlugin

class GoogleSearch(object):
    PLUGIN_ICON = gtk.STOCK_OPEN
    PLUGIN_VERSION = '0.0.1'

    def plugin_songs(self, songs):
        l = dict.fromkeys([song(self.k) for song in songs]).keys()
        for a in l:
            a = quote(str(a))
            website(GOOGLE_MUSICSEARCH_URL % (a, self.g))

class GoogleArtist(GoogleSearch, SongsMenuPlugin):
    PLUGIN_ID = 'Search for artist in Google'
    PLUGIN_NAME = _('Search for artist in Google')
    k = 'artist'
    g = k
    
class GoogleAlbum(GoogleSearch, SongsMenuPlugin):
    PLUGIN_ID = 'Search for album in Google'
    PLUGIN_NAME = _('Search for album in Google')
    k = 'album'
    g = k
    
class GoogleTitle(GoogleSearch, SongsMenuPlugin):
    PLUGIN_ID = 'Search for title in Google'
    PLUGIN_NAME = _('Search for title in Google')
    k = 'title'
    g = 'song'
