#!/bin/sh

# start functions
usage() {
	echo "Usage:"
	echo "- As root, to set the default backend, system-wide:"
	echo "       $0 -b <backend name>"
	echo
	echo "- As a normal user, to run a program with a specific backend:"
	echo "       $0 -b <backend name> <program name> [program options...]"
	echo
	echo "- \"backend name\" is one of gstreamer or xine"
	echo "- \"program name\" is one of totem, totem-audio-preview,"
	echo "  totem-video-indexer or totem-video-thumbnailer"
	echo
	exit 1
}

check_exists() {
  # We've already run checks, this value is valid.
	TOTEM_BACKEND=$1
  # Are we missing the requested backend?
  if [ ! -f $_LIBDIR/libbaconvideowidget-$TOTEM_BACKEND.so.0.0.0 ];then
    echo -e "Error: Cannot use backend $TOTEM_BACKEND, it is not installed."
    echo -e "Please verify your installation";
    exit 1
  fi
}

set_backend() {
  # We've already run checks, this value is valid and it exists
	TOTEM_BACKEND=$1
  /usr/sbin/alternatives --set totem-backend $_LIBDIR/libbaconvideowidget-$TOTEM_BACKEND.so.0.0.0
}
# end functions

TOT_ARCH=$(uname -m)
case ${TOT_ARCH} in
  x86_64 | ia64 | s390 )
    _LIBDIR="/usr/lib64"
    SECONDARY_LIB_DIR="/usr/lib"
    ;;
  * )
    _LIBDIR="/usr/lib"
    SECONDARY_LIB_DIR="/usr/lib64"
    ;;
esac

if [ ! -f ${_LIBDIR}/libbaconvideowidget-gstreamer.so.0.0.0 ]; then
    if [ ! -x ${SECONDARY_LIB_DIR}/libbaconvideowidget-gstreamer.so.0.0.0 ]; then
  echo "Error: ${_LIBDIR}//libbaconvideowidget-gstreamer.so.0.0.0 not found"
  if [ -d ${SECONDARY_LIB_DIR} ]; then
      echo "       ${SECONDARY_LIB_DIR}/libbaconvideowidget-gstreamer.so.0.0.0 not found"
  fi
  exit 1
    fi
    _LIBDIR="${SECONDARY_LIB_DIR}"
fi

TOTEM_BACKEND=$2
BIN=$3
# Check for valid backend
# Default to GStreamer if there's no config
if [ -z $TOTEM_BACKEND ] ; then
	echo "Error: No backend name passed."
	usage
fi
# Default to GStreamer if the backend is invalid
if [ $TOTEM_BACKEND != "xine" -a $TOTEM_BACKEND != "gstreamer" ] ; then
	echo "Error: Invalid backend name."
	usage
fi

# Does the requested backend exist?
check_exists $2

# If root, just try to set the default backend
if [ "$UID" -eq "0" ] ; then
	if [ "$1" != "-b" -o -z "$2" ] ; then
		usage;
	fi
	set_backend $2
else
	if [ "$1" != "-b" -o -z "$2" ] ; then
		usage;
	fi
	if [ $TOTEM_BACKEND != "xine" -a $TOTEM_BACKEND != "gstreamer" ] ; then
		echo "Error: Invalid backend name."
		usage
	fi
	if [ -z "$BIN" ] ; then
		echo "Error: No program name passed."
		usage
	fi
	if [ $BIN != "totem" -a $BIN != "totem-audio-preview" -a $BIN != "totem-video-indexer" -a $BIN != "totem-video-thumbnailer" ] ; then
		echo "Error: Wrong program name."
		usage
	fi
	shift 3
	LD_PRELOAD=libgdk-x11-2.0.so.0:libbaconvideowidget-$TOTEM_BACKEND.so.0.0.0 exec $BIN "$@"
fi
