( rm -f /usr/lib/thunderbird-1.5.0.9/components/compreg.dat )
( /usr/lib/thunderbird-1.5.0.9/thunderbird -register )
